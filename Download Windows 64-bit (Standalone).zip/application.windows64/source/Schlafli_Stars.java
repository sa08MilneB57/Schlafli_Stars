import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Schlafli_Stars extends PApplet {

int P = 7; //<>//
int Q = 3;
float RHO = 1;
String Pstring = Integer.toString(P);
String Qstring = Integer.toString(Q);
final float POINTSIZE = 3;
int TEXTSIZE;
float SCALE;
float relSpeed;
boolean settingP,settingQ;
boolean showCircles = true;
boolean showQShape1 = true;
boolean showQShape2 = true;
boolean showSpiro = true;
boolean showStar = true;
boolean fullMode = true;
boolean showHelp = true;
boolean traceMode = false;
boolean recording = false;
boolean showInfo = true;
Spiro spiro;
Poly star;

public void setup() {
  //size(600, 1000);
  
  SCALE = min(width,height)*0.45f;
  TEXTSIZE = min(width,height)/30;
  textSize(TEXTSIZE);
  refresh();
  
  
  background(0);
  strokeWeight(2);
}

public void refresh(){
  P = Integer.parseInt(Pstring);
  Q = Integer.parseInt(Qstring);
  settingP = false;
  settingQ = false;
  spiro = new Spiro(SCALE, P, Q, RHO);
  star = new Poly(SCALE, P, Q);
  relSpeed = (float)spiro.getMaxT()/(float)star.getMaxT();
}

public void draw() {
  if(traceMode){
    blendMode(SUBTRACT);
    fill(5);
    rect(-10,-10,width+20,height+20);
    blendMode(ADD);
  } else {
    background(0);
  }

  pushMatrix();
    translate(width/2, height/2);
    rotate(-PI/2f);
    scale(1, -1);
  
    float time = 0.5f*0.125f*0.125f*frameCount;
    noFill();
    stroke(50);
    if(showStar){star.show();}
    if(showCircles){spiro.showContainment();}
    if(showSpiro){spiro.show();}
    noFill();
    stroke(HSL(0, 1, 0.5f));
    if(showQShape1){spiro.showQPoints1((time*relSpeed) % spiro.getMaxT(), POINTSIZE,fullMode);}
    stroke(HSL(PI, 1, 0.5f));
    if(showQShape2){spiro.showQPoints2((time*relSpeed) % spiro.getMaxT(), POINTSIZE,fullMode);}
    
    noStroke();
    fill(150,10);
    if(showCircles){spiro.showRoller(time*relSpeed,fullMode);}
  popMatrix();
  
  blendMode(BLEND);
  fill(255);
  if(showHelp){
    textAlign(LEFT,BOTTOM);
    text("Press P or Q to start editing the values in the Schlafli symbol." + 
         "\nOr +/- to change the radius of the pen on the rolling circle." + 
         "\nType with numbers and BACKSPACE. ENTER to confirm." + 
         "\n(Toggle)?:Help Text. A:Rolling shape. S:Formation shape. D:Rollers. I:Info " + 
         "\nF:Full Mode. G:Spirograph. H: Ideal Polygon. T : Trace Mode. R:Record",15,height-TEXTSIZE/2);
  }
  if(showInfo){
    textAlign(LEFT,CENTER);
    text("{P/Q}={" + Pstring + "/" + Qstring + "} = " + spiro.repeats + "{" + (spiro.sides/spiro.repeats) + "/" + (spiro.step/spiro.repeats) + "};  Pen Radius:"+RHO + 
       "\ngcd:" + gcd(P,Q) + " lcm:" + lcm(P,Q) + " Degeneracy:" + (spiro.repeats - 1),15,TEXTSIZE + 5);
    
    if(settingP){
      text("\n\n\n[P-edit on]",20,25);
    } else if (settingQ){
      text("\n\n\n[Q-edit on]",20,25);
    }
  }
  if(recording){
    saveFrame("frames/frame#########.png");
    fill(255,0,0);
    circle(width - 20, 20, 10);
  }
}

public void keyPressed(){
  if(settingP){
    if(key >= '0' && key <= '9'){
      Pstring = Pstring + key;
    } else if (key==BACKSPACE){
      if(Pstring.length() > 0){
        Pstring = Pstring.substring(0,Pstring.length()-1);
      }
    } else if (key==RETURN || key==ENTER){
      if(Pstring.length() > 0){
        refresh();
      }
    }
  } else if(settingQ){
    if(key >= '0' && key <= '9'){
      Qstring = Qstring + key;
    } else if (key==BACKSPACE){
      if(Qstring.length() > 0){
        Qstring = Qstring.substring(0,Qstring.length()-1);
      }
    } else if (key==RETURN || key==ENTER){
      if(Qstring.length() > 0){
        refresh();
      }
    }
  }
  switch(key){
    case '=':
      RHO += 0.125f*0.125f;
      refresh();
      break;
    case '-':
      RHO -= 0.125f*0.125f;
      refresh();
      break;
    case 'p': 
      if(settingQ && Qstring.length() == 0){
        return;
      }
      settingP = true;
      settingQ = false;
      showInfo = true;
      break;
    case 'q': 
      if(settingP && Pstring.length() == 0){
        return;
      }
      settingP = false;
      settingQ = true;
      showInfo = true;
      break;
    case 't':
      traceMode = !traceMode;
      break;
    case 'a':
      showQShape1 = !showQShape1;
      break;
    case 's':
      showQShape2 = !showQShape2;
      break;
    case 'd':
      showCircles = !showCircles;
      break;
    case 'f':
      fullMode = !fullMode;
      break;
    case 'g':
      showSpiro = !showSpiro;
      break;
    case 'h':
      showStar = !showStar;
      break;
    case 'r':
      recording = !recording;
      break;
    case 'i':
      showInfo = !showInfo;
      break;
    case '/':
      showHelp = !showHelp;
      break;
  }
  
}
public int YCoCg(float Y, float Co, float Cg){return YCoCg(Y,Co,Cg,1f);}
public int YCoCg(float Y, float Co, float Cg,float alpha){
  //Y:[0,1] ;  Co,Cg:[-0.5,0.5]
  float tmp =     Y   -  Cg;
  float R = 255f*(tmp +  Co);
  float G = 255f*(Y   +  Cg);
  float B = 255f*(tmp -  Co);
  return color(R,G,B,255f*alpha);  
}

public float[] inverseYCoCg(int col){return inverseYCoCg(red(col),green(col),blue(col));}
public float[] inverseYCoCg(float R,float G, float B){
  R /= 2f*255f;
  G /= 2f*255f;
  B /= 2f*255f;
  
  float[] ycocg = {0.5f*(R+B) + G,
                   (R-B),
                   G - 0.5f*(R+B)};
  return ycocg;
}

public float[] inverseHSL(int col){return inverseHSL(red(col),green(col),blue(col));}
public float[] inverseHSL(float R,float G, float B){
  R /= 255f;
  G /= 255f;
  B /= 255f;
  final float Cmax = max(R,G,B);
  final float Cmin = min(R,G,B);
  final float delta = Cmax - Cmin;
  final float L = 0.5f*(Cmax + Cmin);
  float H,S;
  if (delta==0){
    H = 0f;
    S = 0f;
  } else {
    S = delta/(1f-abs(2*L-1f));
    final float sect = PI/3;
    if (Cmax == R){
      H = sect*( ( (G-B)/delta ) % 6 );
    } else if (Cmax == G){
      H = sect*( ( (B-R)/delta ) + 2 );
    } else if (Cmax == B){
      H = sect*( ( (R-G)/delta ) + 4 );      
    } else {
      throw new RuntimeException("Impossible colour, unreachable code with RGB: (" + R + "," + G + "," + B + ")");
    }
  }
  
  float[] hsl = {H,S,L};
  return hsl;
}


public int HSL(float H, float S, float L) {return HSL(H,S,L,1);}
public int HSL(float H, float S, float L,float alpha) {
  //L and S in [0,1], H in [0,2pi]
  H = ((H%TAU)+TAU)%TAU;
  float C = (1 - abs(2*L - 1)) * S;
  float Hp = 3*H / PI;
  float X = C*(1 - abs((Hp % 2) - 1));
  float R, G, B;
  if (S == 0 || L==0 || L==1) {
    R=0;
    G=0;
    B=0;
  } else {
    switch(floor(Hp)) {
    case 0:
      R=C; 
      G=X; 
      B=0;
      break;
    case 1:
      R=X; 
      G=C; 
      B=0;
      break;
    case 2:
      R=0; 
      G=C; 
      B=X;
      break;
    case 3:
      R=0; 
      G=X; 
      B=C;
      break;
    case 4:
      R=X; 
      G=0; 
      B=C;
      break;
    case 5:
      R=C; 
      G=0; 
      B=X;
      break;
    default:
      R=0; 
      G=0; 
      B=0;
    }
  }
  float m = L - 0.5f*C;
  return color(255*(R+m), 255*(G+m), 255*(B+m),255*alpha);
}
interface Shape{
  public void show();
  public void showPoint(float t,float scale);
  public float getMaxT();
  public void rotate(float angle);//rotates about center of window, not center of self
}

class Poly implements Shape{
  float scale;
  int sides, step,splitting;
  Shape[] subShapes;
  Poly(float _scale, int _sides, int _step){
    if(_sides < 2){throw new IllegalArgumentException("There must be at least 3 points.");}
    if(_step < 1){throw new IllegalArgumentException("Step must be at least 1.");}
    if(_step >= _sides){throw new IllegalArgumentException("Step must be less than Sides.");}
    scale = _scale;
    sides = _sides;
    step = _step;
    splitting = gcd(sides,step);
    if(splitting == 1){
      subShapes = new Line[sides];
      float angle = step*TAU/sides;
      for(int i=0;i<sides;i++){
        PVector x1 = fromPolar(scale,i*angle);
        PVector x2 = fromPolar(scale,(i+1)*angle);
        subShapes[i] = new Line(x1,x2);
      }
    } else {
      subShapes = new Poly[splitting];
      int subShapeSides = sides / splitting;
      int subShapeStep = step / splitting;
      float angleOffset = TAU / sides;
      for(int i=0;i<splitting;i++){
        subShapes[i] = new Poly(scale,subShapeSides,subShapeStep);
        subShapes[i].rotate(angleOffset*i);
      }
    }
  }
  
  public void rotate(float angle){
    for(Shape shape: subShapes){
      shape.rotate(angle);
    }
  }
  
  public void show(){
    for(Shape shape:subShapes){
      shape.show();
    }
  }
  
  public float getMaxT(){
    if(splitting == 1){
      return (float)sides;
    } else {
      float sum = 0;
      for(Shape shape:subShapes){
        sum += shape.getMaxT();
      }
      return sum;
    }
  }
  
  public void showPoint(float t,float scale){
    if(t<0){throw new IllegalArgumentException("t must be greater than 0");}
    if(splitting == 1){
      int passTo = floor(t);
      float passAs = t - passTo;
      subShapes[passTo].showPoint(passAs,scale);
      return;
    } else {
      for(Shape shape:subShapes){
        float shapeLength = shape.getMaxT();
        if(t < shapeLength){
          shape.showPoint(t,scale);
          return;
        } else {
          t -= shapeLength;
        }
      }
    }
    throw new RuntimeException("Didn't find point. Possibly t to large");
  }
  
}

class Line implements Shape{
  PVector start,end;
  Line(PVector _start,PVector _end){
    start = _start;
    end = _end;
  }
  public void rotate(float angle){
    start = start.rotate(angle);
    end = end.rotate(angle);
  }
  public void show(){line(start.x,start.y,end.x,end.y);}
  
  public void showPoint(float t,float scale){
    PVector point = PVector.lerp(start,end,t);
    circle(point.x,point.y,scale);
  }
  
  public float getMaxT(){return 1f;}
  
}
class Spiro implements Shape{
  int sides,step,repeats;
  int reducedSides,reducedStep;
  float K,l,k,R,r,rho,PERIOD;
  float currentAngle = 0;
  Spiro(float scale, int _sides, int _step, float _l){
    if(_sides < 2){throw new IllegalArgumentException("There must be at least 3 points.");}
    if(_step < 1){throw new IllegalArgumentException("Step must be at least 1.");}
    if(_step >= _sides){throw new IllegalArgumentException("Step must be less than Sides.");}
    //if(_l <0 ||_l > 1){throw new IllegalArgumentException("l must be between 0 and 1");}
    sides = _sides;
    step = _step;
    K = (float)sides / (float)step;
    l = _l;
    k = 1f/K;
    R = scale;
    r = k*R;
    repeats = gcd(sides,step);
    reducedSides = sides / repeats;
    reducedStep = step / repeats;
    rho = l*r;
    PERIOD = TAU * lcm(sides,step) / sides;
    currentAngle = 0;
  }
  
  public PVector penAtT(float t){return penAtT(t,0);}
  public PVector penAtT(float t, float offset){
    float theta = t*(1f-K) ;
    return PVector.mult(PVector.add(fromPolar(1-k,t + currentAngle + offset) , fromPolar(l*k,theta + currentAngle + offset)),R);
  }
  
  public PVector[] qPens1(float t){return qPens1(t,0);}
  public PVector[] qPens1(float t,float offset){
    //inscribes the q'-gon in the inner circle
    PVector[] out = new PVector[reducedStep];
    //println(reducedStep);
    float theta = t*(1f-K) ;
    final float dTheta = TAU/reducedStep;
    for (int i=0; i<reducedStep; i++){
      out[i] = PVector.mult(PVector.add(fromPolar(1-k,t + currentAngle + offset) , fromPolar(l*k,theta + currentAngle + offset + i*dTheta)),R);
    }
    return out;
  }
  public PVector[] qPens2(float t){return qPens2(t,0);}
  public PVector[] qPens2(float t,float offset){
    PVector[] out = new PVector[reducedSides - reducedStep];
    float theta = t*(1f-K) ;
    final float dt = TAU/(reducedSides - reducedStep);
    for (int i=0; i<reducedSides - reducedStep; i++){
      out[i] = PVector.mult(PVector.add(fromPolar(1-k,t + currentAngle + offset + i*dt) , fromPolar(l*k,theta + currentAngle + offset)),R);
    }
    return out;
  }
  
  public void showPoint(float t,float scale){
    if(t<0){throw new IllegalArgumentException("t must be greater than 0");}
    if(t >= getMaxT()){t= t % getMaxT();}
    if(repeats == 1){
      PVector x = penAtT(t);
      circle(x.x,x.y,scale);
      return;
    } else {
      println(repeats);
      float theta = TAU/sides;
      for(int n=0; n<=repeats;n++){
        if(t < PERIOD){
          PVector x = penAtT(t,n*theta);
          circle(x.x,x.y,scale);
          return;
        } else {
          t -= PERIOD;
        }
      }
    }
    throw new RuntimeException("Didn't find point. Possibly t to large");
  }
  
  public void showQPoints1(float t, float scale,boolean full){
    if(t<0){throw new IllegalArgumentException("t must be greater than 0");}
    if(t>=getMaxT()){t= t%getMaxT();}
    int polyCount = (full)?(reducedSides - reducedStep):1;
    float polySep = TAU/polyCount;
    if(repeats == 1){
      for(int j=0; j<polyCount;j++){
        PVector[] poly  = qPens1(t+j*polySep);
        for(int i=0;i<poly.length;i++){
          circle(poly[i].x,poly[i].y,scale);
          line(poly[i].x,poly[i].y,poly[(i+1)%poly.length].x,poly[(i+1)%poly.length].y);
        }
      }
      return;
    } else {
      float theta = TAU/sides;
      for(int n=0; n<=repeats;n++){
        if(t < PERIOD){
          for(int j=0; j<polyCount;j++){
            PVector[] poly  = qPens1(t+j*polySep,theta*n);
            for(int i=0;i<poly.length;i++){
              circle(poly[i].x,poly[i].y,scale);
              line(poly[i].x,poly[i].y,poly[(i+1)%poly.length].x,poly[(i+1)%poly.length].y);
            }
          }
          return;
        } else {
          t -= PERIOD;
        }
      }
    }
    throw new RuntimeException("Didn't find point. Possibly t to large");
  }
  
  public void showQPoints2(float t, float scale,boolean full){
    if(t<0){throw new IllegalArgumentException("t must be greater than 0");}
    if(t>=getMaxT()){t= t%getMaxT();}
    int polyCount = (full)?(reducedStep):1;
    float polySep = TAU/(reducedSides - reducedStep);
    if(repeats == 1){
      for(int j=0; j<polyCount;j++){
        PVector[] poly  = qPens2(t - j*polySep);
        for(int i=0;i<poly.length;i++){
          circle(poly[i].x,poly[i].y,scale);
          line(poly[i].x,poly[i].y,poly[(i+1)%poly.length].x,poly[(i+1)%poly.length].y);
        }
      }
      return;
    } else {
      float theta = TAU/sides;
      for(int n=0; n<=repeats;n++){
        if(t < PERIOD){
          for(int j=0; j<polyCount;j++){
            PVector[] poly  = qPens2(t - j*polySep,theta*n);
            for(int i=0;i<poly.length;i++){
              circle(poly[i].x,poly[i].y,scale);
              line(poly[i].x,poly[i].y,poly[(i+1)%poly.length].x,poly[(i+1)%poly.length].y);
            }
          }
          return;
        } else {
          t -= PERIOD;
        }
      }
    }
    throw new RuntimeException("Didn't find point. Possibly t to large");
  }
  
  public void showRoller(float t,boolean full){
    if(t<0){throw new IllegalArgumentException("t must be greater than 0");}
    if(t>=getMaxT()){t= t%getMaxT();}
    int wheels = (full)?reducedSides - reducedStep:1;
    float dWheel = TAU/(wheels);
    float dRepeat = TAU/sides;
    for(int n=0; n<=repeats;n++){
      if(t<PERIOD){
        for(int i=0;i<wheels;i++){
          circle((R-r)*cos(t + i*dWheel + n*dRepeat),(R-r)*sin(t+ i*dWheel + n*dRepeat),2*r);
        }
        return;
      } else {
        t -= PERIOD;
      }
    }
  }
  
  public void showContainment(){
    circle(0,0,2*R);
  }
  
  public void rotate(float angle){currentAngle += angle;}
  
  public float getMaxT(){return repeats*PERIOD;}
  
  public void show(){
    final int detail = 1024;
    final float dt = getMaxT()/(detail+1);
    final float theta = TAU/P;
    final float dColor = TAU/repeats;
    for (int n=0; n<repeats;n++){
      stroke(HSL(TAU/3f + n*dColor,1,0.1f));
      for(int i=0; i<detail;i++){
        PVector x1 = penAtT(   i *dt, n*theta);
        PVector x2 = penAtT((i+1)*dt, n*theta);
        line(x1.x,x1.y,x2.x,x2.y);
      }
    }
  }

}

public PVector fromPolar(float r,float theta){
  return new PVector(r*cos(theta),r*sin(theta));
}

public int gcd(int a, int b) {
   if (b==0) return a;
   return gcd(b,a%b);
}

public int lcm(int a, int b){
  if(a==0 && b ==0){return 0;}
  return abs(a*b)/gcd(a,b);
}

//int[] pointIndices(int points,int step){
//  if(points < 3){throw new IllegalArgumentException("There must be at least 3 points.");}
//  int[] out = new int[points];
//  for (int i=0; i<points; i++){
//    out[i] = (i*step) % points;
//  }
//}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Schlafli_Stars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
